import axios from 'axios';
export const name = 'tempMail';
export const command = ['tempmail','tempinbox','readmail','delmail'];
export const handler = async (sock, msg, args, { from }) => {
  const cmd = msg.command;
  if (cmd === 'tempmail') {
    const res = await axios.get('https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1');
    await sock.sendMessage(from, { text: `Email: ${res.data[0]}` });
  }
  if (cmd === 'tempinbox') {
    if (!args[0]) return sock.sendMessage(from, { text: 'Usage: tempinbox <email@address.com>' });
    const parts = args[0].split('@');
    if (parts.length < 2) return sock.sendMessage(from, { text: 'Invalid email address format.' });
    const [user, domain] = parts;
    const res = await axios.get(`https://www.1secmail.com/api/v1/?action=getMessages&login=${user}&domain=${domain}`);
    await sock.sendMessage(from, { text: JSON.stringify(res.data, null, 2) });
  }
};